import React from 'react'


const Sidebar = () => {

    return (

        <>
            Sidebar
        </>
    )
}

export default Sidebar
