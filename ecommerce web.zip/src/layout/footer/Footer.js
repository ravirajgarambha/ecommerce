import React from 'react'
import { Link } from 'react-router-dom'

function Footer() {
    return (
        <div>
footer
        </div>
    )
}

export default Footer
