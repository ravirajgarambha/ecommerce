# Compastrips Backend

### Requirements


  node 14.17.0 (npm 6.14.13) & above
  Postgresql server (Database Name: test)


### Instructions

1. run `npm install`
2. run `npm start` to start server
3. start developing